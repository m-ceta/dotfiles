
## From RankNet to LambdaRank to LambdaMART: A Revisit

Please refer to [ptranking_lambda_framework.ipynb](https://github.com/ptranking/ptranking.github.io/raw/master/tutorial/) for detailed description.
