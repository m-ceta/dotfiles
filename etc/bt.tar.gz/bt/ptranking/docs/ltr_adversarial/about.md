
## About ltr_adversarial
By **ltr_adversarial**, we refer to the adversarial learning-to-rank methods inspired by the generative adversarial network
(GAN) and its variants.
