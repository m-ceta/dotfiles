
## About ltr_tree
By **ltr_tree**, we refer to the learning-to-rank methods based on the framework of Gradient Boosting Decision Tree (GBDT).
