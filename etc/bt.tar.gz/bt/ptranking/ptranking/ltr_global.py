
"""Description
Global Variable
"""

""" Seed """
ltr_seed = 137

""" A Tiny Value """
epsilon  = 1e-8
